Please download and install the RichClient-Toolset first,
now from a changed domain: 
http://www.vbRichClient.com/Downloads/vbRC5BaseDlls.zip (2.2MB, without WebKit)
http://www.vbRichClient.com/Downloads/WebKitCairo.7z (3.2MB, the optional WebKit-Package) 
The contained 'WebkitCairo'-Folder of the above WebKitCairo.7z-package just needs to be placed within
the RichClient5-Dll-directory - as a Folder - e.g. ensure the following placement for optional WebKit-support:
C:\RC5\
   vbRichClient5.dll
   vb_cairo_sqlite.dll
   DirectCOM.dll
   \WebKitCairo\

In the above Folder-structure, only the vbRichClient5.dll has to be registered 
(in "elevated mode" - as an Admin - per regsvr32.exe or an appropriate alternative.

Plain Cairo-Drawing (no Widgets anywhere) is done in this Demo -
to get a feeling about the new graphics- and rendering-commands
the RC5-wrapper has to offer.

It is recommended, to make your way through the Tutorial-steps
in increasing order - I've tried to cover most of the cairo-
functionality in "a chain", which seemed "right to me" with regards
to a "step-by-step-understanding" - but inform me, when you feel,
that I've lost you somewhere - I'm happy to include a new step
"#8 B" on request, if you find there's somewhere "a gap too large".
Please mail me directly under os@vbRichClient.com, if you have such 
an request, maybe paired with some ideas already - but also feel
free, to post your own examples in case these could be useful
for other users when "officially included" here in the "main-tutorial"). 

With RC5-based cairo, VB-Classic is on its way to "bleeding edge" again 
(at least with regards to modern drawing) - and the cairo-lib, whilst 
known, not to be  the "very fastest" among modern 2D-engines, has some 
huge potential especially due to its flexibility and easy userinterface.
Just look into Demo #17 - how you can work with the very same Drawing-
Calls which you perform first against "Pixel-Surfaces" - but with a simple 
"Surface-Switch" you can also render a similar looking PDF-Document directly.

IMO that's the strength of cairo - the "multi-surface-support" - 
and with regards to performance you can expect much in the next months
from cairo too - on Linux a (reworked now) OpenGL-backend is already
doing pretty well - and for the Windows-Platform the FireFox-Developers
(which use cairo for their renderings too) have already a working binding
of the brand-new MS-Direct2D- and DirectWrite-backends up and running.

So, have fun with the tutorial - (and I'm sure you will... <g>)
and let's find some "community-spirit" again over the next months
and years - there must be something like that, damn it...;-)


Olaf Schmidt,

in March, 2013