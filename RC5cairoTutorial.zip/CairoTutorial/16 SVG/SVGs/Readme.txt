Please note, that the included Oxygen-Icons come under LGPL now,
(read more about that under: http://www.oxygen-icons.org/?page_id=4 
 under the 'Theme'-section)
which is fine, since you are allowed to use and ship parts of this 
huge Icon-Theme (containing thousands of icons) together with your 
commercial App ... 
but only as long as you do *not* link these SVG-resources directly
into your *commercial* binaries (Exes or Dlls).

So, please leave the Icon-Resources either as "standalone-Files"
in a SubDirectory of your App (with a hint to their LGPL-licensing) -
or store them within a Resource-Binary (as e.g. a simple Res.-Dll),
which you then should publish under LGPL too (the Res.Dll-Source).

Anyways... Have fun with the Cairo-Wrapper and its included
SVG-Rendering support... :-)

Olaf Schmidt (sss@online.de - in April 2010)