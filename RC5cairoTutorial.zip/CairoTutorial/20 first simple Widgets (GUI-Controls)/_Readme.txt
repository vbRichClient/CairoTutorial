This last "Folder 20" here, concludes this tutorial - 
by introducing the Widget-Engine already.
(please read the comments within the project).

The three (more or less) simple cwWidget-Classes, which
are demonstrated here, do not yet use the also supported
Theming-Engine of the RC5. To develop more sophisticated
Widgets (incorporating theming), you should take a look
at the new Widget-Tutorial here:
   www.vbRichClient.com/Downloads/RC5widgetsTutorial.zip

Please check on the above WebSite regularly, for news and
updates - currently (march 2013) the Website is not yet "launched"
(despite being able to download from it ;-), but I will do 
so - prividing more examples and information about the 
much more improved Widget-Stack of the RC5 on this site.


Happy Coding!

Olaf Schmidt