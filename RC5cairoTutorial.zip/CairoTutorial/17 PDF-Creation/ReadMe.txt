Whilst all the other Demos in this tutorial are completely "Public-Domain",
please take care with this Demo here, since it is using a Class (cPDFDoc),
which demonstrates a __cdecl-Binding to an OpenSource-lib (libmupdf.dll),
which comes under GPL.

Please act with the source of cPDFDoc according to the requirements of this 
license: https://code.google.com/p/sumatrapdf/source/browse/trunk/COPYING

There's additional comments in the Class cPDFDoc.

Olaf Schmidt, march 2013